<!-- #changelog -->
<div id="changelog" class="bpanel-content">

    <!-- .bpanel-main-content -->
    <div class="bpanel-main-content no-margin">

        <!-- #tab1-changelog -->
        <div id="tab1" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php echo constant('THEME_NAME'); esc_html_e(' Theme Change Log', 'classy-missy');?></h3>
                </div>
                
                <div class="box-content">
                <pre>
18.03.2017 - version 1.0
 * First release!</pre>
                </div><!-- .box-content -->
            </div><!-- .bpanel-box end -->            
        </div><!--#tab1-import-demo end-->

    </div><!-- .bpanel-main-content end-->
</div><!-- #changelog end-->